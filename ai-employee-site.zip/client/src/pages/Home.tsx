import { useState } from "react";
import {
  ArrowRight,
  ArrowUpRight,
  BarChart3,
  CalendarCheck2,
  Check,
  CheckCircle2,
  ChevronDown,
  Clock3,
  FileText,
  Globe2,
  Menu,
  MessageCircle,
  PhoneCall,
  Play,
  RefreshCcw,
  ShieldCheck,
  Sparkles,
  Store,
  UsersRound,
  X,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

const features = [
  {
    icon: MessageCircle,
    number: "01",
    title: "Answer every inquiry",
    copy: "Responds to WhatsApp, web, and Instagram messages in your tone — day or night.",
    color: "blue",
  },
  {
    icon: FileText,
    number: "02",
    title: "Send polished quotes",
    copy: "Turns a conversation into a clear, on-brand quote without making you lift a finger.",
    color: "lime",
  },
  {
    icon: RefreshCcw,
    number: "03",
    title: "Follow up, naturally",
    copy: "Knows when to check back in and what to say, so warm leads never go cold.",
    color: "violet",
  },
  {
    icon: CalendarCheck2,
    number: "04",
    title: "Book the next step",
    copy: "Finds a time, confirms the details, and keeps your calendar moving while you work.",
    color: "orange",
  },
];

const faqs = [
  {
    question: "Is it a chatbot or a real employee?",
    answer:
      "It is an AI employee built to work like a thoughtful member of your team. It handles the repetitive front desk work, follows your rules, and knows when to hand a conversation over to a human.",
  },
  {
    question: "What channels can it handle?",
    answer:
      "Start with WhatsApp and add your website chat, Instagram, or email as your business grows. Every conversation stays in one simple workspace.",
  },
  {
    question: "Will it sound like my business?",
    answer:
      "Yes. During setup, you share your services, pricing guardrails, FAQs, and a few example replies. Your AI employee uses that context to match your tone and stay on-brand.",
  },
  {
    question: "Can I see what it is doing?",
    answer:
      "Absolutely. You can review conversations, approve sensitive quotes, jump into any thread, and see the key metrics that matter to your business.",
  },
];

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
}

export default function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [submitted, setSubmitted] = useState(false);

  const goTo = (id: string) => {
    setMenuOpen(false);
    scrollToId(id);
  };

  const handleDemo = () => {
    toast.success("Thanks — we’ll be in touch with a short walkthrough.");
    scrollToId("contact");
  };

  return (
    <div className="min-h-screen overflow-x-hidden bg-[#f8f8f5] text-[#14161a]">
      <header className="site-header">
        <div className="container flex h-[76px] items-center justify-between">
          <a href="#top" className="brand-mark" aria-label="Kivo home">
            <span className="brand-symbol">✦</span>
            <span>Kivo</span>
          </a>
          <nav className="hidden items-center gap-8 md:flex" aria-label="Main navigation">
            <button onClick={() => goTo("handles")} className="nav-link">What it handles</button>
            <button onClick={() => goTo("how-it-works")} className="nav-link">How it works</button>
            <button onClick={() => goTo("pricing")} className="nav-link">Pricing</button>
            <button onClick={() => goTo("faq")} className="nav-link">FAQ</button>
          </nav>
          <div className="hidden items-center gap-5 md:flex">
            <button onClick={() => toast.info("A product tour is on its way.")} className="nav-link">Log in</button>
            <button onClick={handleDemo} className="button button-dark button-small">See how it works <ArrowUpRight size={15} /></button>
          </div>
          <button
            className="mobile-menu-button md:hidden"
            onClick={() => setMenuOpen((value) => !value)}
            aria-label={menuOpen ? "Close menu" : "Open menu"}
            aria-expanded={menuOpen}
          >
            {menuOpen ? <X size={21} /> : <Menu size={21} />}
          </button>
        </div>
        {menuOpen && (
          <div className="mobile-menu md:hidden">
            <button onClick={() => goTo("handles")}>What it handles</button>
            <button onClick={() => goTo("how-it-works")}>How it works</button>
            <button onClick={() => goTo("pricing")}>Pricing</button>
            <button onClick={() => goTo("faq")}>FAQ</button>
            <button onClick={handleDemo} className="button button-dark">See how it works <ArrowUpRight size={16} /></button>
          </div>
        )}
      </header>

      <main id="top">
        <section className="hero-section">
          <div className="container relative z-10 grid items-center gap-14 pb-16 pt-14 lg:grid-cols-[0.91fr_1.09fr] lg:gap-8 lg:pb-24 lg:pt-20">
            <div className="hero-copy max-w-[640px]">
              <div className="eyebrow animate-in"><span className="eyebrow-dot" /> AI that keeps business moving</div>
              <h1 className="display-heading animate-in delay-1">Your best employee<br /><span className="heading-accent">never clocks out.</span></h1>
              <p className="hero-lead animate-in delay-2">Kivo handles the conversations that keep small businesses busy — inquiries, quotes, follow-ups, bookings, and the little things in between.</p>
              <div className="mt-9 flex flex-wrap items-center gap-4 animate-in delay-3">
                <button onClick={handleDemo} className="button button-dark">Put Kivo to work <ArrowRight size={17} /></button>
                <button onClick={() => goTo("how-it-works")} className="button button-quiet"><span className="play-icon"><Play size={12} fill="currentColor" /></span> Take the 90-sec tour</button>
              </div>
              <div className="hero-note animate-in delay-4"><ShieldCheck size={16} /> No credit card. Setup in one afternoon.</div>
            </div>

            <div className="hero-visual animate-in delay-2" aria-label="Kivo conversation preview">
              <div className="hero-orbit orbit-one" />
              <div className="hero-orbit orbit-two" />
              <div className="hero-glow" />
              <div className="hero-image-frame">
                <img src="/manus-storage/ai-employee-orb_6a8df7c7.png" alt="Abstract cobalt AI orb with soft light trails" />
                <div className="visual-overlay" />
              </div>
              <div className="message-card message-card-top">
                <div className="avatar avatar-green">M</div>
                <div><strong>Hi, is this available<br />for Saturday?</strong><small>WhatsApp · just now</small></div>
                <span className="status-dot" />
              </div>
              <div className="message-card message-card-bottom">
                <div className="kivo-mini">✦</div>
                <div><strong>Absolutely — I’ve saved<br />your spot for 10:30 AM.</strong><small>Sent by Kivo · 2 sec ago</small></div>
                <CheckCircle2 size={17} className="message-check" />
              </div>
              <div className="floating-stat"><Zap size={14} fill="currentColor" /><span><b>47%</b><small>more replies</small></span></div>
            </div>
          </div>
          <div className="hero-marquee" aria-label="Customer promise">
            <div className="container flex flex-wrap items-center justify-between gap-4">
              <p>Built for the business you’re building.</p>
              <div className="marquee-points"><span><span className="mini-check">✓</span> human when it matters</span><span><span className="mini-check">✓</span> helpful by default</span><span><span className="mini-check">✓</span> always learning</span></div>
            </div>
          </div>
        </section>

        <section className="logo-strip">
          <div className="container flex flex-wrap items-center justify-between gap-5">
            <p className="strip-label">Trusted by owner-operators in 18+ industries</p>
            <div className="industry-list"><span>STUDIO NINE</span><span>north&co</span><span className="industry-serif">FIELD<br />HOUSE</span><span>GOODFORM</span><span className="industry-round">Morrow</span></div>
          </div>
        </section>

        <section id="handles" className="section section-light">
          <div className="container">
            <div className="section-intro grid gap-8 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
              <div><div className="eyebrow"><span className="eyebrow-dot" /> More momentum, less admin</div><h2 className="section-heading">A little more<br /><em>done</em> every day.</h2></div>
              <p className="section-lead">The tasks that slip between the cracks are exactly the ones Kivo is made for. It works in the background, so you can stay in the work that only you can do.</p>
            </div>
            <div className="feature-grid mt-16">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return <article key={feature.title} className={`feature-card feature-${feature.color}`} style={{ animationDelay: `${index * 70}ms` }}>
                  <div className="feature-top"><span className="feature-number">{feature.number}</span><span className="feature-icon"><Icon size={21} /></span></div>
                  <h3>{feature.title}</h3><p>{feature.copy}</p><ArrowUpRight size={18} className="feature-arrow" />
                </article>;
              })}
            </div>
          </div>
        </section>

        <section id="how-it-works" className="section section-dark">
          <div className="container">
            <div className="dark-intro grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
              <div><div className="eyebrow eyebrow-light"><span className="eyebrow-dot" /> One calm command center</div><h2 className="section-heading heading-light">The work behind<br />the <em>work.</em></h2></div>
              <p className="section-lead lead-light">Give Kivo your context once. It learns your voice, your offers, your availability, and the way you like things done. Then it gets on with it.</p>
            </div>
            <div className="workflow-layout mt-16">
              <div className="workflow-steps">
                <div className="workflow-step active"><span>01</span><div><h3>Connect your channels</h3><p>Bring your WhatsApp, website, and calendar together in a few clicks.</p></div></div>
                <div className="workflow-step"><span>02</span><div><h3>Teach it your way</h3><p>Add your FAQs, pricing, policies, and the personality you want customers to feel.</p></div></div>
                <div className="workflow-step"><span>03</span><div><h3>Watch it get to work</h3><p>Keep an eye on every conversation, or let Kivo run the front desk while you focus.</p></div></div>
              </div>
              <div className="dashboard-mockup">
                <div className="dashboard-bar"><span className="dash-brand"><span>✦</span> Kivo</span><span className="dash-window">Today, 10:42 AM <span className="dash-avatar">JD</span></span></div>
                <div className="dashboard-body"><div className="dash-sidebar"><span className="dash-side-active"><MessageCircle size={14} /> Inbox <b>12</b></span><span><CalendarCheck2 size={14} /> Bookings</span><span><BarChart3 size={14} /> Insights</span><span><Store size={14} /> Business</span></div>
                  <div className="dash-main"><div className="dash-heading"><div><small>OVERVIEW</small><h4>Good morning, Jordan.</h4></div><span className="dash-live"><i /> Live</span></div><div className="dash-metrics"><div><small>CONVERSATIONS</small><strong>128</strong><span className="metric-up">↑ 18%</span></div><div><small>BOOKINGS</small><strong>24</strong><span className="metric-up">↑ 12%</span></div><div><small>REPLY TIME</small><strong>1m 42s</strong><span className="metric-neutral">on average</span></div></div><div className="conversation-preview"><div className="conversation-title"><span>RECENT CONVERSATIONS</span><span>View all <ArrowUpRight size={12} /></span></div><div className="conversation-row"><div className="row-avatar row-mint">S</div><div><b>Sarah at Willow Studio</b><p>Perfect, I’ll take the Tuesday slot.</p></div><time>2m</time><span className="row-status">Booked</span></div><div className="conversation-row"><div className="row-avatar row-blue">A</div><div><b>Arjun · Website chat</b><p>Can you send me a quote for...</p></div><time>8m</time><span className="row-status warm">Quote sent</span></div></div></div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="section section-tint">
          <div className="container quote-layout">
            <div className="quote-mark">“</div>
            <div><p className="big-quote">Kivo gave me my evenings back. I still sound like me — I just get to be me in more conversations now.</p><div className="quote-person"><div className="person-photo">AM</div><div><strong>Amara Mensah</strong><span>Founder, Morrow Skin Studio</span></div><div className="quote-rule" /><div className="quote-stat"><strong>6.4 hrs</strong><span>saved every week</span></div></div></div>
          </div>
        </section>

        <section id="pricing" className="section section-light pricing-section">
          <div className="container">
            <div className="center-intro"><div className="eyebrow"><span className="eyebrow-dot" /> Simple, sensible pricing</div><h2 className="section-heading">Start small.<br /><em>Grow calmly.</em></h2><p className="section-lead">No per-message surprises. Pick the amount of help your business needs today and change it when you’re ready.</p></div>
            <div className="pricing-grid mt-14">
              <article className="price-card"><div className="price-label">ESSENTIAL</div><h3>For a lighter front desk</h3><p>Everything you need to stop missing the good stuff.</p><div className="price"><strong>$79</strong><span>/ month</span></div><button onClick={handleDemo} className="button button-outline">Start with Essential <ArrowRight size={16} /></button><div className="price-divider" /><ul>{["WhatsApp + web chat", "1,000 conversations / month", "Quotes and follow-ups", "Shared team inbox"].map((item) => <li key={item}><Check size={15} />{item}</li>)}</ul></article>
              <article className="price-card price-card-featured"><div className="popular-pill">MOST POPULAR</div><div className="price-label">MOMENTUM</div><h3>For businesses in motion</h3><p>More channels, more context, more time back.</p><div className="price"><strong>$149</strong><span>/ month</span></div><button onClick={handleDemo} className="button button-dark">Put Kivo to work <ArrowRight size={16} /></button><div className="price-divider" /><ul>{["Everything in Essential", "5,000 conversations / month", "Bookings + calendar sync", "Priority human handoff"].map((item) => <li key={item}><Check size={15} />{item}</li>)}</ul></article>
              <article className="price-card price-card-custom"><div className="price-label">CUSTOM</div><h3>For teams with a bigger brief</h3><p>Tailored workflows, deeper integrations, and a plan that fits.</p><div className="custom-price">Let’s talk</div><button onClick={() => toast.info("A specialist will reach out shortly.")} className="button button-outline">Talk to a human <ArrowRight size={16} /></button><div className="price-divider" /><ul>{["Multi-location support", "Custom knowledge base", "Advanced reporting", "Dedicated onboarding"].map((item) => <li key={item}><Check size={15} />{item}</li>)}</ul></article>
            </div>
          </div>
        </section>

        <section id="faq" className="section faq-section">
          <div className="container faq-layout"><div><div className="eyebrow"><span className="eyebrow-dot" /> Questions, answered</div><h2 className="section-heading">Good to<br /><em>know.</em></h2><p className="section-lead">Still curious? We like that. If it’s not here, ask us anything.</p><button onClick={() => toast.info("We’ll connect you with a human shortly.")} className="text-link mt-7">Ask a question <ArrowUpRight size={16} /></button></div><div className="faq-list">{faqs.map((faq, index) => <div className={`faq-item ${openFaq === index ? "faq-open" : ""}`} key={faq.question}><button onClick={() => setOpenFaq(openFaq === index ? null : index)} aria-expanded={openFaq === index}><span>{faq.question}</span><ChevronDown size={18} /></button>{openFaq === index && <p>{faq.answer}</p>}</div>)}</div></div>
        </section>

        <section id="contact" className="cta-section">
          <div className="container cta-inner"><div className="cta-sparkle">✦</div><div><div className="eyebrow eyebrow-light"><span className="eyebrow-dot" /> Ready when you are</div><h2>Give your business<br /><em>room to grow.</em></h2><p>Tell us a little about what’s keeping you busy. We’ll show you where Kivo can help first.</p></div><form className="cta-form" onSubmit={(event) => { event.preventDefault(); setSubmitted(true); toast.success("You’re on the list — we’ll be in touch soon."); }}><div className="form-row"><input required type="email" placeholder="Your work email" aria-label="Your work email" /><button className="button button-lime" type="submit">{submitted ? "You’re on the list ✓" : "Show me how"} <ArrowRight size={16} /></button></div><span><CheckCircle2 size={14} /> No sales script. Just a useful conversation.</span></form></div>
        </section>
      </main>

      <footer className="site-footer"><div className="container footer-top"><a href="#top" className="brand-mark brand-footer"><span className="brand-symbol">✦</span><span>Kivo</span></a><p>The small business AI employee.</p><div className="footer-links"><a href="#handles">What it handles</a><a href="#pricing">Pricing</a><a href="#faq">FAQ</a><a href="#contact">Contact</a></div></div><div className="container footer-bottom"><span>© 2025 Kivo Technologies</span><span><Globe2 size={14} /> Built for businesses everywhere</span><span>Privacy · Terms</span></div></footer>
    </div>
  );
}
